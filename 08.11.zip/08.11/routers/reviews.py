from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from database import get_db
import models
import schemas
from routers.auth_courier import auth, TokenPayload

router = APIRouter(prefix="/api/reviews", tags=["Reviews"])

@router.post("/{courier_id}", response_model=schemas.ReviewResponse, status_code=201)
def create_review(courier_id: int, data: schemas.ReviewCreate, db: Session = Depends(get_db)):
    courier = db.query(models.Courier).filter(models.Courier.id == courier_id).first()
    if not courier:
        raise HTTPException(status_code=404, detail="Курьер не найден")

    review = models.Review(
        courier_id=courier_id,
        rating=data.rating,
        comment=data.comment,
        client_name=data.client_name
    )
    db.add(review)
    db.commit()
    db.refresh(review)
    return review

@router.get("/my", response_model=List[schemas.ReviewResponse])
def get_my_reviews(payload: TokenPayload = Depends(auth.access_token_required), db: Session = Depends(get_db)):
    courier_id = int(payload.sub)
    return db.query(models.Review).filter(models.Review.courier_id == courier_id).all()

@router.delete("/{review_id}")
def delete_review(review_id: int, db: Session = Depends(get_db)):
    review = db.query(models.Review).filter(models.Review.id == review_id).first()
    if not review:
        raise HTTPException(status_code=404, detail="Отзыв не найден")
    db.delete(review)
    db.commit()
    return {"message": "Отзыв успешно удален"}